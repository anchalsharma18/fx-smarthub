import React from "react";

export default function App() {
  return (
    <div style={{ fontFamily: "Arial, sans-serif", padding: "2rem" }}>
      <h1>FX SmartHub</h1>
      <p>Your ultimate hub for forex tools, calculators, and trading journals.</p>

      <section>
        <h2>🔥 Premium MT5 & MT4 EAs</h2>
        <ul>
          <li>Download ready-to-use Expert Advisors</li>
          <li>Risk-managed automation</li>
          <li>Backtested for consistency</li>
        </ul>
      </section>

      <section>
        <h2>📈 Trading Calculators</h2>
        <ul>
          <li>Pip Value Calculator</li>
          <li>Risk Management Tool</li>
          <li>Lot Size Calculator</li>
        </ul>
      </section>

      <section>
        <h2>📝 Trading Journal</h2>
        <p>Track your progress like a pro.</p>
        <p><strong>Price:</strong> $20 (Free with any premium pack)</p>
      </section>

      <footer style={{ marginTop: "2rem" }}>
        <p>&copy; 2025 FX SmartHub. All rights reserved.</p>
      </footer>
    </div>
  );
}
